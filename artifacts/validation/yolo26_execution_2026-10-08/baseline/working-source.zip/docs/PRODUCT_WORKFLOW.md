# Tennis analysis product

## Start

Use the existing project Python environment with the installed model dependencies, and Node 22+. Install the existing frontend dependencies with `pnpm install --frozen-lockfile` from `frontend/` if needed. FFmpeg and ffprobe must be on PATH (or use the overrides below).

Build the website once, then serve the website and API together:

```powershell
# In frontend/
pnpm build
# From the repository root, using the ML Python environment:
python scripts/run/serve_product.py
```

Open [the local website](http://127.0.0.1:8000/). Choose **Upload match**, select or drop an MP4, MOV or AVI, and click **Analyze match**. The upload shows byte progress; analysis shows the current stage, not an invented completion percentage. Open a completed session to explore source playback, 2D/3D court replay, player motion, heatmaps, measured statistics and downloadable annotated video/JSON. The **Annotated AI video** disclosure provides rendered playback. Historical demos remain available in the session picker.

For frontend development, run `pnpm dev` in `frontend/` and `python -m uvicorn src.api.app:app --host 127.0.0.1 --port 8000` from the repository root. Vite proxies `/api` to the backend. Coach configuration still uses the existing `ASTRA_GPT_*` environment variables; see `ASTRA_TENNIS.md`.

The shell on the verified Windows host resolves `python` to MSYS without the ML dependencies. Its installed ML interpreter is `C:\Users\ac-98\AppData\Local\Programs\Python\Python313\python.exe`. Use this full path if needed. No machine-wide environment changes are required.

## Processing and storage

- The API streams the raw video request body with a bounded byte count and checks the filename extension and container signature. The worker checks video metadata, then fully decodes/transcodes it before inference. The default limit is 1 GiB, 120 FPS, two hours and 3840 × 2160 pixels. The duration and upload-byte limits can be configured.
- IDs are random `match_<32 hex characters>` values. Client filenames are display metadata, never filesystem paths. Original uploads are stored in `outputs/product/uploads/<id>/original.<extension>`.
- SQLite at `outputs/product/analyses.sqlite3` records upload, processing, completion or failure, stage, timestamps and sanitized errors. One worker holds an OS-backed file lock, serializing GPU inference. It runs separately from HTTP, so accepted work continues through web-server restarts. Another server process cannot recover or claim the active worker's job while that lock is held.
- If the worker itself dies, the next worker marks interrupted processing jobs failed and starts queued uploads. Completed analyses remain available. A failed analysis can be retried by uploading its video again, creating a new ID and preserving the failed evidence.
- Outputs and detailed `processing.log` are stored in `outputs/product/analyses/<id>/`. Invalid/failed output is never published as a completed run. Raw uploads and completed results are retained; back up this directory as one unit. Failed/disconnected requests clean up their own temporary files. Hard process termination during an upload may leave an orphan `upload.part`; it is not a queued job and can be removed by the operator after confirming no upload is active.
- `source.mp4` is H.264 at constant frame rate for deterministic playback and inference. The uploaded original is retained separately. Normalization follows source presentation time and duplicates/drops frames for variable-rate inputs; all inference timestamps refer to the normalized timeline. Audio is omitted from analysis playback; the original download retains it. No audio analysis is claimed.
- `annotated.mp4` is the existing pipeline output; `annotated_web.mp4` is its H.264 browser copy. Both browser videos are decoded and frame-count checked before publication. HTTP byte ranges support playback seeking.
- `run_config.yaml` and the per-job config retain the existing model recipe and unique match ID. No training, model replacement or accuracy promotion is performed.

## Configuration

| Variable | Default / purpose |
| --- | --- |
| `TENNIS_STORAGE_ROOT` | Absolute path to `outputs/product` |
| `TENNIS_PIPELINE_CONFIG` | Existing `configs/phase6_analytics/wasb_tiled_residual_pose_small_validation.yaml` |
| `TENNIS_MAX_UPLOAD_BYTES` | `1073741824` |
| `TENNIS_MAX_DURATION_SECONDS` | `7200` |
| `TENNIS_FFMPEG`, `TENNIS_FFPROBE` | Optional absolute executable paths |

Changing configuration applies to new jobs. The server must be restarted to reload its settings. The default is the previously measured experimental WASB/pose/racket recipe, with event authority withheld. All referenced weights and the existing WASB source directory must already be present. Missing assets produce a clear failed-job message; the product does not download or replace models.

This is a local, single-host product. It has no account isolation or public-hosting authentication. Keep it bound to loopback. Remote multi-user deployment is outside this integration and needs its own access-control and quota design.

## Data contract and limits

The result adapter reads Phase 6 exports and maps `player_motion.json` to frame-aligned ground paths and speed samples. It retains confidence, camera-loss gaps and nullable values. Required invalid metadata/trajectory frames fail publication. Optional malformed dashboard sections show **Analysis unavailable for this section** while valid sections remain accessible.

Ball speed, bounce placement, rally/shot statistics and scoring remain unavailable when the selected pipeline withholds them. Two-dimensional ball projection is not measured three-dimensional flight. Player IDs are near/far roles, not recognized names; speed and distance are estimates over observed contiguous intervals. Court reprojection residual is fit consistency, not independent court accuracy. Uploaded sessions never inherit the illustrative player rankings, names or match statistics from legacy showcase pages.

## Endpoints

| Endpoint | Purpose |
| --- | --- |
| `GET /api/health` | Availability and upload limits |
| `POST /api/analyses?filename=match.mp4` | Raw video bytes; returns 202 and persistent job ID |
| `GET /api/analyses` | Most recent 200 job records |
| `GET /api/analyses/{id}` | Status, stage, timestamps and sanitized error |
| `GET /api/runs` | Lightweight completed run summaries |
| `GET /api/analyses/{id}/result` | Validated dashboard data; 409 until complete |
| `GET /api/analyses/{id}/media/source` | Normalized original playback |
| `GET /api/analyses/{id}/media/annotated` | Annotated playback |
| `GET /api/analyses/{id}/download/{kind}` | `original`, `annotated` or `report` |
| `/api/coach`, `/api/coach/status` | Existing configurable coach adapter |

## Verification

```powershell
python -m pytest tests -q -p no:cacheprovider
# In frontend/
pnpm check
```

Tests cover bounded uploads, extension/container rejection, path isolation, queue transitions and interrupted-job recovery, media ranges, required output validation, missing optional sections, camera gaps, live result loading, timezone-aware timestamps and upload UI states. Real-model end-to-end evidence is recorded separately in `docs/evaluation/PRODUCT_INTEGRATION_RESULTS.md`.
