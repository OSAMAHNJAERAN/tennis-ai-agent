import { Link } from 'react-router-dom';
import { useProductResource } from '../hooks/useProductResource';
import { matchTitle, type ProductMatch } from '../data/productApi';
import { PageHeader, Card } from '../components/ui';
import { ProductError } from './ProductHome';

export default function ProductInsights() {
  const resource = useProductResource<ProductMatch[]>('/api/matches', 10000);
  return <div className="page product-page"><PageHeader eyebrow="EVIDENCE FIRST" title="AI Insights" description="Review observations, coaching and your notes in the context of each match." /><ProductError error={resource.error} retry={resource.refresh} /><Card className="product-panel"><h2>Predictions are not connected</h2><p>Win probabilities, player-form predictions and automated tactical claims will appear only when a connected service supplies supported results.</p></Card>{!resource.data && !resource.error ? <p role="status">Loading matches…</p> : null}{resource.data?.length === 0 ? <p className="product-empty">Upload a match or start a manual live session to build an evidence history.</p> : null}{resource.data?.filter(m => m.source === 'manual' || m.status === 'COMPLETED').map(match => <Card className="product-panel" key={match.id}><h2>{matchTitle(match)}</h2><p>{match.source === 'manual' ? `${match.score?.statistics.reduce((n, p) => n + p.points_won, 0) ?? 0} points recorded. Review point and service/return statistics.` : 'Review player positioning observations with the source video and selected frame interval.'}</p><p className="product-hint">Source: {match.source === 'manual' ? 'manual score log' : 'recorded video telemetry'} · Updated {new Date(match.updated_at).toLocaleString()}</p><Link className="button" to={`/matches/${match.id}?section=insights`}>Review insights & notes</Link></Card>)}</div>;
}
