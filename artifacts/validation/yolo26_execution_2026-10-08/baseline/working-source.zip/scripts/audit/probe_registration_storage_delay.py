"""Bounded read-only timing probe against the retained interrupted database."""
import cProfile
import gc
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import pstats
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
AFTER_FILL = '--after-fill' in sys.argv
FIXTURE_COUNT = int(sys.argv[sys.argv.index('--fixture-count') + 1]) if '--fixture-count' in sys.argv else 432000
FULL_PATTERN = '--full-pattern' in sys.argv or AFTER_FILL
CONNECTION_PROBE = '--connection-probe' in sys.argv
PLAIN_PROBE = '--plain-probe' in sys.argv
if CONNECTION_PROBE and not AFTER_FILL:
    raise ValueError('Connection probe requires a fresh append fixture')
PROBE_LABEL = sys.argv[sys.argv.index('--probe-label') + 1] if '--probe-label' in sys.argv else None
if PROBE_LABEL is not None and (not PROBE_LABEL.isascii() or not PROBE_LABEL.replace('_', '').isalnum()):
    raise ValueError('Probe label must contain only ASCII letters, digits, or underscores')
UNIT = ROOT / (('artifacts/validation/product_execution/registration_storage_delay_probe_after_fill_2026-10-05' if FIXTURE_COUNT == 432000 else
               'artifacts/validation/product_execution/registration_storage_delay_probe_after_fill_' + str(FIXTURE_COUNT) + '_2026-10-05') if AFTER_FILL else
              'artifacts/validation/product_execution/registration_storage_delay_probe_full_pattern_2026-10-05'
               if FULL_PATTERN else 'artifacts/validation/product_execution/registration_storage_delay_probe_2026-10-05')
if PROBE_LABEL is not None:
    UNIT = UNIT.with_name(UNIT.name + '_' + PROBE_LABEL)
DATA = ROOT / 'artifacts/validation/product_execution/registration_storage_measurement_2026-10-05/dynamic_432000_new'
CLEAN = ROOT / 'artifacts/validation/product_installation/clean_env/Scripts/python.exe'


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def load_monitor():
    spec = importlib.util.spec_from_file_location('delay_probe_monitor', ROOT / 'scripts/audit/measure_candidate_storage.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def child():
    import cv2
    import numpy as np
    import psutil
    from src.court.calibration import CourtCalibration
    from src.utils.frame_registration_sequence import _decode_record, FrameRegistration, FrameRegistrationSequence
    database, = DATA.glob('frame_registration_*.sqlite3')
    points = np.arange(28, dtype=np.float32).reshape(1, 14, 2)

    def generated(index):
        dtype = np.float32 if index % 2 else np.float64
        matrix = np.array([[.125, -.0, (index % 127) / 64], [0., .25, -.125], [0., 0., 1.]], dtype=dtype)
        reason = 'CAMERA_CUT' if index % 19 == 0 else None
        calibration = CourtCalibration(None if index % 17 == 0 else matrix, (True, False, True),
                                       (index % 127) / 64, -.0, .0625, reason)
        transform = None if reason or calibration.image_to_court is None else np.array(
            [[1., -.0, (index % 31) / 8], [0., 1., .25], [0., 0., 1.]], dtype=dtype)
        return FrameRegistration(calibration, transform)

    def encoded(record):
        calibration = record.calibration
        def array(value):
            return None if value is None else [value.dtype.str, list(value.shape), value.tobytes(order='C').hex()]
        def scalar(value):
            return None if value is None else float(value).hex()
        projected = calibration.project_ground_point((11.5, 40.25))
        transformed = (None if record.anchor_to_frame_px is None else
                       cv2.perspectiveTransform(points, record.anchor_to_frame_px)[0])
        value = [array(calibration.image_to_court), list(calibration.inlier_mask),
                 scalar(calibration.reprojection_error_px), scalar(calibration.reprojection_error_m),
                 scalar(calibration.inlier_reprojection_error_px), calibration.rejection_reason,
                 array(record.anchor_to_frame_px), calibration.is_valid, calibration.inlier_count,
                 None if projected is None else [scalar(item) for item in projected], array(transformed)]
        return json.dumps(value, separators=(',', ':'), allow_nan=False).encode('ascii')

    stages = []
    def generated_only():
        checksum = hashlib.sha256()
        profiler = cProfile.Profile()
        cpu_start, thread_start, wall_start = time.process_time(), time.thread_time(), time.perf_counter()
        profiler.enable()
        for index in range(1000):
            observed = encoded(generated(index))
            checksum.update(len(observed).to_bytes(4, 'big'))
            checksum.update(observed)
        profiler.disable()
        elapsed = time.perf_counter() - wall_start
        top = sorted(pstats.Stats(profiler).stats.items(), key=lambda item: item[1][3], reverse=True)[:8]
        return {'frames': 1000, 'wallSeconds': elapsed, 'processCpuSeconds': time.process_time() - cpu_start,
                'threadCpuSeconds': time.thread_time() - thread_start, 'sha256': checksum.hexdigest(),
                'gcCounts': gc.get_count(),
                'topCumulative': [{'function': key[2], 'file': Path(key[0]).name, 'calls': value[1],
                                   'totalSeconds': value[2], 'cumulativeSeconds': value[3]} for key, value in top]}
    plain_before = generated_only() if PLAIN_PROBE else None
    fixture = None
    fill_seconds = None
    if AFTER_FILL:
        fixture = FrameRegistrationSequence(UNIT)
        fixture.__enter__()
        begin = time.perf_counter()
        fixture.extend(generated(index) for index in range(FIXTURE_COUNT))
        fixture._connection.commit()
        fill_seconds = time.perf_counter() - begin
        connection = fixture._connection
    else:
        connection = sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)
    plain_after = generated_only() if PLAIN_PROBE else None
    queried_database = fixture.path if fixture is not None else database
    fresh_reader = None
    gc_events = []
    gc_started = {}
    def gc_timing(phase, info):
        generation = info['generation']
        if phase == 'start':
            gc_started[generation] = time.perf_counter()
        elif generation in gc_started:
            gc_events.append({'generation': generation, 'seconds': time.perf_counter() - gc_started.pop(generation),
                              'collected': info['collected'], 'uncollectable': info['uncollectable']})
    gc.callbacks.append(gc_timing)
    try:
        connection.execute('PRAGMA query_only=ON')
        connection.execute('PRAGMA cache_size=-2048')
        count, minimum, maximum = connection.execute('SELECT COUNT(*),MIN(frame_index),MAX(frame_index) FROM registration_frames').fetchone()
        # Diagnostic injection uses the actual indexed read implementation over
        # this read-only connection. It never enters/cleans up owned storage.
        sequence = FrameRegistrationSequence(DATA)
        sequence._connection, sequence._length = connection, count
        cursor_referenceState = [{'type': type(value).__name__, 'length': len(value)}
                                 for value in gc.get_referents(connection) if isinstance(value, (list, dict, tuple))]
        query = 'SELECT metadata,image_matrix,anchor_transform FROM registration_frames WHERE frame_index=?'
        plan = connection.execute('EXPLAIN QUERY PLAN ' + query, (0,)).fetchall()
        windows = [('original', connection, 0), ('original', connection, count - 1000)]
        if CONNECTION_PROBE:
            fresh_reader = sqlite3.connect(queried_database.as_uri() + '?mode=ro', uri=True)
            fresh_reader.execute('PRAGMA query_only=ON')
            fresh_reader.execute('PRAGMA cache_size=-2048')
            fresh_reader.execute('PRAGMA temp_store=FILE')
            fresh_reader.execute('PRAGMA mmap_size=0').fetchone()
            windows = [('original_before', connection, 0), ('fresh_read_only', fresh_reader, 0),
                       ('original_after', connection, 0)]
        for connection_label, active_connection, start in windows:
            sequence._connection = active_connection
            gc_offset = len(gc_events)
            stage_cpu = time.process_time()
            stage_thread_cpu = time.thread_time()
            begin = time.perf_counter()
            records = []
            for index in range(start, start + 1000):
                records.append(_decode_record(active_connection.execute(query, (index,)).fetchone()))
            read_seconds = time.perf_counter() - begin
            profiler = cProfile.Profile()
            begin = time.perf_counter()
            profiler.enable()
            checksum = hashlib.sha256()
            if FULL_PATTERN:
                for index in range(start, start + 1000):
                    expected = encoded(generated(index))
                    observed = encoded(sequence[index])
                    assert expected == observed
                    checksum.update(len(observed).to_bytes(4, 'big'))
                    checksum.update(observed)
            else:
                for record in records:
                    checksum.update(encoded(record))
            profiler.disable()
            encode_seconds = time.perf_counter() - begin
            stats = pstats.Stats(profiler).stats
            top = sorted(stats.items(), key=lambda item: item[1][3], reverse=True)[:12]
            stages.append({'connection': connection_label, 'startFrame': start, 'frames': 1000, 'readDecodeSeconds': read_seconds,
                           'profiledGeometryEncodingSeconds': encode_seconds, 'sha256': checksum.hexdigest(),
                           'processCpuSeconds': time.process_time() - stage_cpu,
                           'threadCpuSeconds': time.thread_time() - stage_thread_cpu,
                           'gcEvents': gc_events[gc_offset:],
                           'topCumulative': [{'function': key[2], 'file': Path(key[0]).name, 'line': key[1],
                                              'calls': value[1], 'totalSeconds': value[2], 'cumulativeSeconds': value[3]}
                                             for key, value in top]})
            del records
    finally:
        gc.callbacks.remove(gc_timing)
        if fresh_reader is not None:
            fresh_reader.close()
        if fixture is not None:
            fixture.__exit__(*sys.exc_info())
        else:
            connection.close()
    actual = psutil.Process()
    result = {'recordedAt': datetime.now(timezone.utc).isoformat(), 'actualWorkloadIdentity': {'pid': actual.pid, 'createTimeUnixSeconds': actual.create_time()},
              'database': queried_database.relative_to(ROOT).as_posix(),
              'retainedReferenceDatabase': database.relative_to(ROOT).as_posix(),
              'connectionProbe': CONNECTION_PROBE, 'rows': count, 'minimumFrame': minimum, 'maximumFrame': maximum,
              'generatedOnlyBeforeFill': plain_before, 'generatedOnlyAfterFill': plain_after,
              'queryPlan': plan, 'stages': stages, 'threads': actual.num_threads(),
              'fullGeneratedComparisonAndActualIndexedRead': FULL_PATTERN,
              'freshAppendFixtureCount': FIXTURE_COUNT if AFTER_FILL else None, 'fixtureAppendSeconds': fill_seconds,
              'connectionContainerReferencesAfterPreparation': cursor_referenceState,
              'pythonVersion': sys.version, 'libraries': {'numpy': np.__version__, 'opencv': cv2.__version__},
              'peakWorkingSetBytes': actual.memory_info().peak_wset,
              'fastLoop': all(row['readDecodeSeconds'] + row['profiledGeometryEncodingSeconds'] < .3 for row in stages),
              'diagnosticThresholdSecondsPer1000Records': .3, 'inferenceRun': False, 'retainedDatabaseReadOnly': True,
              'ownedFixtureRemovedOnSuccess': fixture is not None and not fixture.path.exists(),
              'scope': '1000-record first/last windows only; diagnostic threshold, not product throughput or qualification.'}
    save(UNIT / 'child_receipt.json', result)
    print(json.dumps(result), flush=True)
    return 0 if result['fastLoop'] else 1


def parent():
    UNIT.mkdir(parents=True, exist_ok=False)
    with (UNIT / 'executed_probe_registration_storage_delay.py').open('xb') as stream:
        stream.write(Path(__file__).read_bytes())
    import psutil
    monitor = load_monitor()
    process = owned = None
    receipt = {'startedAt': datetime.now(timezone.utc).isoformat(), 'inferenceRun': False}
    try:
        with (UNIT / 'stdout.txt').open('x', encoding='utf-8') as log:
            process = subprocess.Popen([str(CLEAN), str(Path(__file__)), '--child'] +
                                       (['--after-fill', '--fixture-count', str(FIXTURE_COUNT)] if AFTER_FILL else ['--full-pattern'] if FULL_PATTERN else []) +
                                       (['--connection-probe'] if CONNECTION_PROBE else []) +
                                       (['--plain-probe'] if PLAIN_PROBE else []) +
                                       (['--probe-label', PROBE_LABEL] if PROBE_LABEL else []), cwd=ROOT,
                                       stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
            owned = monitor.OwnedProcessTree(process)
            begin = time.monotonic()
            while process.poll() is None:
                rows = owned.sample()
                if sum(row['memoryBytes']['rss'] for row in rows) > 1000000000 or time.monotonic() - begin > 30:
                    raise RuntimeError('Probe exceeded predeclared RAM/wall guard')
                time.sleep(.05)
        result = json.loads((UNIT / 'child_receipt.json').read_text(encoding='utf-8'))
        receipt['exitCode'] = process.returncode
        receipt['actualWorkloadWasSampled'] = owned.observed_workload(result['actualWorkloadIdentity'])
        receipt['remainingOwnedIdentities'] = owned.wait_for_retirement()
        assert receipt['actualWorkloadWasSampled'] and not receipt['remainingOwnedIdentities']
        receipt['probeExecuted'] = True
        receipt['fastLoop'] = result['fastLoop']
        print(json.dumps({'probeExecuted': True, 'fastLoop': result['fastLoop'], 'rows': result['rows'], 'stages': result['stages'], 'threads': result['threads']}))
        return process.returncode
    except BaseException as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        if process is not None:
            receipt['terminationActions'] = monitor.stop_owned(process, owned)
        raise
    finally:
        receipt['completedAt'] = datetime.now(timezone.utc).isoformat()
        if owned is not None:
            receipt['ownedIdentities'] = owned.identities()
        save(UNIT / 'resource_receipt.json', receipt)


if __name__ == '__main__':
    sys.path.insert(0, str(ROOT))
    raise SystemExit(child() if '--child' in sys.argv else parent())
